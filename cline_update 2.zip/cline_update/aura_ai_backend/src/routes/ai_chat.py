"""
AI Chat Routes for Aura AI Backend
Handles chat requests and routes them to appropriate AI providers
"""

from flask import Blueprint, request, jsonify, redirect, session
from src.services.ai_service import AIService, AIProvider
import json
import secrets

ai_chat_bp = Blueprint('ai_chat', __name__)
ai_service = AIService()

@ai_chat_bp.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages and route to appropriate AI provider"""
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({
                'success': False,
                'error': 'Message is required'
            }), 400
        
        message = data['message']
        context = data.get('context', {})
        provider_preference = data.get('provider')  # Optional provider selection
        
        # Add user session context for authentication
        if 'cline_token' in session:
            context['cline_token'] = session['cline_token']
        
        # If user specified a provider, try to use it
        if provider_preference:
            context['preferred_provider'] = provider_preference
        
        # Route message to appropriate AI
        result = ai_service.route_message(message, context)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Server error: {str(e)}'
        }), 500

@ai_chat_bp.route('/cline/auth/login', methods=['GET'])
def cline_login():
    """Initiate CLINE authentication flow"""
    try:
        # Generate state for OAuth security
        state = secrets.token_urlsafe(32)
        session['oauth_state'] = state
        
        # For now, return the CLINE login URL
        # In production, this would redirect to CLINE's OAuth endpoint
        return jsonify({
            'success': True,
            'login_url': 'https://app.cline.bot/login',
            'state': state,
            'providers': ['google', 'github'],
            'message': 'Please complete authentication at app.cline.bot'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Authentication error: {str(e)}'
        }), 500

@ai_chat_bp.route('/cline/auth/callback', methods=['POST'])
def cline_auth_callback():
    """Handle CLINE authentication callback"""
    try:
        data = request.get_json()
        auth_code = data.get('code')
        state = data.get('state')
        provider = data.get('provider', 'google')
        
        # Verify state for security
        if state != session.get('oauth_state'):
            return jsonify({
                'success': False,
                'error': 'Invalid state parameter'
            }), 400
        
        if not auth_code:
            return jsonify({
                'success': False,
                'error': 'Authorization code required'
            }), 400
        
        # Authenticate with CLINE
        cline_provider = ai_service.providers[AIProvider.CLINE]
        auth_result = cline_provider.authenticate_user(auth_code, provider)
        
        if auth_result['success']:
            # Store authentication in session
            session['cline_token'] = auth_result['token']
            session['cline_user_id'] = auth_result['user_id']
            session['cline_provider'] = auth_result['provider']
            
            return jsonify({
                'success': True,
                'message': 'Successfully authenticated with CLINE AI!',
                'user_id': auth_result['user_id'],
                'provider': auth_result['provider']
            })
        else:
            return jsonify({
                'success': False,
                'error': 'CLINE authentication failed'
            }), 401
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Callback error: {str(e)}'
        }), 500

@ai_chat_bp.route('/cline/auth/status', methods=['GET'])
def cline_auth_status():
    """Check CLINE authentication status"""
    try:
        is_authenticated = 'cline_token' in session
        
        if is_authenticated:
            return jsonify({
                'success': True,
                'authenticated': True,
                'user_id': session.get('cline_user_id'),
                'provider': session.get('cline_provider'),
                'message': 'CLINE AI is ready for coding tasks!'
            })
        else:
            return jsonify({
                'success': True,
                'authenticated': False,
                'message': 'Please sign in to CLINE AI to access coding features'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Status check error: {str(e)}'
        }), 500

@ai_chat_bp.route('/cline/auth/logout', methods=['POST'])
def cline_logout():
    """Logout from CLINE"""
    try:
        # Clear CLINE session data
        session.pop('cline_token', None)
        session.pop('cline_user_id', None)
        session.pop('cline_provider', None)
        session.pop('oauth_state', None)
        
        return jsonify({
            'success': True,
            'message': 'Successfully logged out from CLINE AI'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Logout error: {str(e)}'
        }), 500

@ai_chat_bp.route('/providers', methods=['GET'])
def get_providers():
    """Get list of available AI providers"""
    try:
        providers = ai_service.get_available_providers()
        return jsonify({
            'success': True,
            'providers': providers
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Server error: {str(e)}'
        }), 500

@ai_chat_bp.route('/chat/stream', methods=['POST'])
def chat_stream():
    """Handle streaming chat responses (future implementation)"""
    return jsonify({
        'success': False,
        'error': 'Streaming not yet implemented'
    }), 501

@ai_chat_bp.route('/chat/history', methods=['GET'])
def get_chat_history():
    """Get chat history (future implementation with database)"""
    return jsonify({
        'success': True,
        'history': [],
        'message': 'Chat history feature coming soon'
    })

@ai_chat_bp.route('/chat/clear', methods=['POST'])
def clear_chat():
    """Clear chat history"""
    return jsonify({
        'success': True,
        'message': 'Chat cleared successfully'
    })

@ai_chat_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'success': True,
        'status': 'healthy',
        'service': 'Aura AI Backend',
        'version': '1.0.0'
    })

