import React, { useState, useCallback, useEffect } from 'react';
import { View, StyleSheet, Alert, TouchableOpacity, Text } from 'react-native';
import { GiftedChat, Bubble, InputToolbar, Send } from 'react-native-gifted-chat';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Speech from 'expo-speech';
import * as Linking from 'expo-linking';

// Update this IP to match your computer's IP address
const API_BASE = 'http://192.168.1.58:5002/api';

export default function ChatScreen() {
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [clineAuth, setClineAuth] = useState({ authenticated: false, user_id: null });

  useEffect(() => {
    checkClineAuthStatus();
    // Initialize with welcome message
    setMessages([
      {
        _id: 1,
        text: "🚀 Hi! I'm AURA AI with CLINE integration! I can help you with:\n\n🤖 CLINE AI - #1 Priority for coding tasks\n🧠 Multiple AI models for different needs\n💼 Business automation with Abacus\n🔍 Deep reasoning with DeepSeek\n💬 General chat with OpenAI\n\nFor coding tasks, I'll automatically use CLINE AI (sign in required). How can I help you today?",
        createdAt: new Date(),
        user: {
          _id: 2,
          name: 'AURA AI',
          avatar: 'https://ui-avatars.com/api/?name=AURA&background=6200EE&color=fff&size=128',
        },
      },
    ]);
  }, []);

  const checkClineAuthStatus = async () => {
    try {
      const response = await fetch(`${API_BASE}/cline/auth/status`);
      const data = await response.json();
      setClineAuth({
        authenticated: data.authenticated,
        user_id: data.user_id,
        provider: data.provider
      });
    } catch (error) {
      console.error('Error checking CLINE auth:', error);
    }
  };

  const handleClineLogin = async () => {
    try {
      const response = await fetch(`${API_BASE}/cline/auth/login`);
      const data = await response.json();
      
      if (data.success) {
        // Open CLINE login page
        const supported = await Linking.canOpenURL(data.login_url);
        if (supported) {
          await Linking.openURL(data.login_url);
          Alert.alert(
            "🔐 CLINE Authentication",
            "Please complete the login process in your browser:\n\n1. Choose Google or GitHub\n2. Complete authentication\n3. Return to this app\n4. Tap 'Refresh Status' below",
            [
              { text: "Refresh Status", onPress: checkClineAuthStatus },
              { text: "Cancel", style: "cancel" }
            ]
          );
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to initiate CLINE login');
    }
  };

  const onSend = useCallback(async (newMessages = []) => {
    setMessages(previousMessages => GiftedChat.append(previousMessages, newMessages));
    
    const userMessage = newMessages[0].text;
    setIsTyping(true);

    try {
      const response = await fetch(`${API_BASE}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userMessage,
          context: {}
        }),
      });

      const data = await response.json();

      if (data.success) {
        const aiMessage = {
          _id: Math.round(Math.random() * 1000000),
          text: `${data.response}\n\n🤖 Powered by: ${data.provider.toUpperCase()} AI`,
          createdAt: new Date(),
          user: {
            _id: 2,
            name: `AURA AI (${data.provider.toUpperCase()})`,
            avatar: 'https://ui-avatars.com/api/?name=AURA&background=6200EE&color=fff&size=128',
          },
        };

        setMessages(previousMessages => GiftedChat.append(previousMessages, [aiMessage]));
        
        // If CLINE authentication is required, refresh status
        if (data.response.includes('CLINE AI Authentication Required')) {
          checkClineAuthStatus();
        }
      } else {
        throw new Error(data.error);
      }
      
      setIsTyping(false);
      
    } catch (error) {
      setIsTyping(false);
      const errorMessage = {
        _id: Math.round(Math.random() * 1000000),
        text: `❌ Error: ${error.message}\n\nPlease check your connection and try again.`,
        createdAt: new Date(),
        user: {
          _id: 2,
          name: 'AURA AI',
          avatar: 'https://ui-avatars.com/api/?name=AURA&background=FF0000&color=fff&size=128',
        },
      };
      setMessages(previousMessages => GiftedChat.append(previousMessages, [errorMessage]));
    }
  }, []);

  const renderBubble = (props) => {
    return (
      <Bubble
        {...props}
        wrapperStyle={{
          right: {
            backgroundColor: '#6200EE',
          },
          left: {
            backgroundColor: '#f0f0f0',
          },
        }}
        textStyle={{
          right: {
            color: '#fff',
          },
          left: {
            color: '#000',
          },
        }}
      />
    );
  };

  const renderInputToolbar = (props) => {
    return (
      <InputToolbar
        {...props}
        containerStyle={styles.inputToolbar}
        primaryStyle={styles.inputPrimary}
      />
    );
  };

  const renderSend = (props) => {
    return (
      <Send {...props}>
        <View style={styles.sendButton}>
          <Ionicons name="send" size={24} color="#6200EE" />
        </View>
      </Send>
    );
  };

  const renderAccessory = () => {
    return (
      <View style={styles.accessoryContainer}>
        <View style={styles.statusContainer}>
          <Text style={styles.statusText}>
            🤖 CLINE AI: {clineAuth.authenticated ? '✅ Connected' : '❌ Not Connected'}
          </Text>
          {clineAuth.authenticated && (
            <Text style={styles.userText}>
              👤 {clineAuth.provider} user: {clineAuth.user_id}
            </Text>
          )}
        </View>
        <View style={styles.buttonContainer}>
          {!clineAuth.authenticated ? (
            <TouchableOpacity style={styles.loginButton} onPress={handleClineLogin}>
              <Ionicons name="log-in" size={16} color="white" />
              <Text style={styles.loginButtonText}>Sign in to CLINE</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={styles.refreshButton} onPress={checkClineAuthStatus}>
              <Ionicons name="refresh" size={16} color="white" />
              <Text style={styles.refreshButtonText}>Refresh</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  };

  return (
    <LinearGradient
      colors={['#6200EE', '#3700B3', '#FFFFFF']}
      style={styles.container}
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
    >
      <GiftedChat
        messages={messages}
        onSend={onSend}
        user={{
          _id: 1,
        }}
        renderBubble={renderBubble}
        renderInputToolbar={renderInputToolbar}
        renderSend={renderSend}
        renderAccessory={renderAccessory}
        isTyping={isTyping}
        placeholder="Ask me anything... (coding tasks → CLINE AI)"
        alwaysShowSend
        scrollToBottom
        showUserAvatar={false}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  inputToolbar: {
    borderTopWidth: 1,
    borderTopColor: '#e8e8e8',
    backgroundColor: 'white',
    borderRadius: 25,
    marginHorizontal: 10,
    marginVertical: 5,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  inputPrimary: {
    alignItems: 'center',
  },
  sendButton: {
    marginRight: 10,
    marginBottom: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  accessoryContainer: {
    backgroundColor: 'rgba(98, 0, 238, 0.1)',
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#e8e8e8',
  },
  statusContainer: {
    flex: 1,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#6200EE',
  },
  userText: {
    fontSize: 10,
    color: '#666',
    marginTop: 2,
  },
  buttonContainer: {
    marginLeft: 10,
  },
  loginButton: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  loginButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
    marginLeft: 5,
  },
  refreshButton: {
    backgroundColor: '#34C759',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  refreshButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
    marginLeft: 5,
  },
});
